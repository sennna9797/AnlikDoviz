﻿using Currency.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;

namespace Currency.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {

            List<DovizModel> CurList = null;

            WebClient client = new WebClient();

            var json = client.DownloadString("https://www.tcmb.gov.tr/wps/wcm/connect/tr/tcmb+tr/main+page+site+area/bugun");

            CurList = JsonConvert.DeserializeObject<List<DovizModel>>(json);

            if (CurList == null)
                return null;

            return View(CurList.Take(3).ToList());


           
        }
    }
}
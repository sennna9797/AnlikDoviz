﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Currency.Models
{
    public class DovizModel
    {
        public string code { get; set; }

        public string name { get; set; }

        public string full_name { get; set; }

        public string selling { get; set; }

        public string buying { get; set; }


    }
}